0.0.10 2014-05-31 ::

    Corrected classifiers in __init__.py. Added ReadTheDocs doc.
    Added prep_rst2pdf.py and prep_rst2pdf.py to help build.bat.
    Changed build.bat.


0.0.9 2014-05-30 ::

    Added py_app_ver.py and changed build.bat.


0.0.8 2014-05-30 ::

    Corrected yml and __init__.py because numpy is not installing in Py3


0.0.7 2014-05-30 ::

    Corrected test and yml files


0.0.6 2014-05-29 ::

    Added Shippable CI


0.0.5 2014-05-29 ::

    Added doctests, packaging, build automation, sphinx doc, travis.
    Changed license and versioning.


0.0.4 2013-07-03 ::

    Added ROC and MA envelopes


0.0.3 2013-06-30 ::

    Added WMA and more EMA types.


0.0.2 2013-06-18 ::

   Added Bollinger bandwidth and %B
   Created a GitHub repository


0.0.1 2013-06-05 ::

   Includes RSI, SMA, EMA and BB
