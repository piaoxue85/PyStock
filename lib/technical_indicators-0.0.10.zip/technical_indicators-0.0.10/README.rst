technical_indicators
====================

This module provides some technical indicators for analysing stocks.

When I can I will add more.

If anyone wishes to contribute with new code or corrections/suggestions, feel free.


**Features:**

    Relative Strength Index (RSI), ROC, MA envelopes
    Simple Moving Average (SMA), Weighted Moving Average (WMA), Exponential Moving Average (EMA)
    Bollinger Bands (BB), Bollinger Bandwidth, %B


**Dependencies:**

It requires numpy.

This module was done and tested under Windows with Python 2.7.3 and numpy 1.6.1.