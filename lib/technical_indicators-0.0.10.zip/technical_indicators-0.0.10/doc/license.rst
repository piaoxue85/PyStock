.. include:: ../LICENSE.rst
